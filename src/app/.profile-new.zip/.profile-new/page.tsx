// // // // src/app/profile/page.tsx


'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
// import Link from 'next/link';
import './profile.css';
import '../contacts/contacts.css';
import AnimatedWrapper from '@/components/animation/AnimatedWrapper';

import { useOrders, useOrderDetails } from '@/hooks/useOrders';
// import { FormattedOrder } from './types_orders';


const getStatusClass = (status: string) => {
    switch (status) {
        case 'processing': return 'accepted';
        case 'completed': return 'completed';
        case 'on-hold': return 'pending';
        default: return 'default';
    }
};

const getStatusText = (status: string) => {
    switch (status) {
        case 'processing': return 'Принят';
        case 'completed': return 'Выполнен';
        case 'on-hold': return 'Ожидает оплаты';
        default: return status;
    }
};


export default function ProfilePage() {
    const [activeSection, setActiveSection] = useState<'profile' | 'orders' | 'favorites' | 'points' | 'support'>('profile');
    const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
    const [userName, setUserName] = useState<string>('');
    const [userEmail, setUserEmail] = useState<string>('');
    const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState(true);
    const router = useRouter();

    // подробная инфа
    const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
    const { orderDetails, isLoading: orderDetailsLoading, error: orderDetailsError } = useOrderDetails(selectedOrderId);

    // Вынесли хук на верхний уровень
    const { orders, isLoading: ordersLoading, error: ordersError } = useOrders();

    useEffect(() => {
        document.title = 'Личный кабинет - Vitaline';
        const metaDescription = document.querySelector('meta[name="description"]');
        if (metaDescription) {
            metaDescription.setAttribute('content', 'Профиль | Служба поддержки');
        } else {
            const meta = document.createElement('meta');
            meta.name = 'description';
            meta.content = 'Профиль | Служба поддержки';
            document.head.appendChild(meta);
        }
    }, []);

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                // Получаем текущий токен из куки через наш API
                const authResponse = await fetch('/api/auth/check', {
                    credentials: 'include'
                });

                if (!authResponse.ok) {
                    throw new Error('Unauthorized');
                }

                const authData = await authResponse.json();

                // Получаем данные пользователя из WordPress
                const userResponse = await fetch('https://nuxt.vitaline.uz/wp-json/wp/v2/users/me', {
                    headers: {
                        'Authorization': `Bearer ${authData.token}`
                    }
                });

                if (!userResponse.ok) {
                    throw new Error('Failed to fetch user data');
                }

                const userData = await userResponse.json();
                setUserName(userData.name || '');
                setUserEmail(userData.email || '');
                setIsAuthenticated(true);
            } catch (error) {
                console.error('Auth error:', error);
                router.replace('/login');
            } finally {
                setIsLoading(false);
            }
        };

        fetchUserData();
    }, [router]);

    const handleLogout = async () => {
        try {
            await fetch('/api/auth/logout', {
                method: 'POST',
                credentials: 'include'
            });
            router.push('/login');
        } catch (error) {
            console.error('Logout error:', error);
        }
    };

    if (isLoading) {
        return null; // или компонент загрузки
    }

    if (!isAuthenticated) {
        return null;
    }

    const renderContent = () => {
        const fadeInUp = {
            initial: { opacity: 0, y: 20 },
            animate: { opacity: 1, y: 0 },
            exit: { opacity: 0, y: 20 },
            transition: { duration: 0.5, ease: 'easeOut' },
        };

        switch (activeSection) {
            case 'profile':
                return (
                    <motion.div {...fadeInUp} key="profile">
                        <div className="profile-page-content">
                            <h2>Персональная информация</h2>
                            <form className='profile_form' action="">
                                <div className="form-group">
                                    <label>Имя</label>
                                    <input type="text" value={userName} readOnly />
                                </div>
                                <div className="form-group">
                                    <label>Телефон</label>
                                    <input type="text" placeholder="+998 XX XXX-XX-XX" />
                                </div>
                                <div className="form-group">
                                    <label>Электронная почта</label>
                                    <input type="email" value={userEmail} disabled />
                                </div>
                                <button className="save-button">Сохранить ваш номер телефона</button>
                            </form>
                        </div>
                    </motion.div>
                );
            // case 'orders': {
            //     if (ordersLoading) {
            //         return (
            //             <motion.div {...fadeInUp} key="orders">
            //                 <div className="profile-page-content">
            //                     <h2>Мои заказы</h2>
            //                     <div className="loading">Загрузка заказов...</div>
            //                 </div>
            //             </motion.div>
            //         );
            //     }

            //     if (ordersError) {
            //         return (
            //             <motion.div {...fadeInUp} key="orders">
            //                 <div className="profile-page-content">
            //                     <h2>Мои заказы</h2>
            //                     <div className="error">{ordersError}</div>
            //                 </div>
            //             </motion.div>
            //         );
            //     }

            //     const getStatusClass = (status: string) => {
            //         switch (status) {
            //             case 'processing': return 'accepted';
            //             case 'completed': return 'completed';
            //             case 'on-hold': return 'pending';
            //             default: return 'default';
            //         }
            //     };

            //     const getStatusText = (status: string) => {
            //         switch (status) {
            //             case 'processing': return 'Принят';
            //             case 'completed': return 'Выполнен';
            //             case 'on-hold': return 'Ожидает оплаты';
            //             default: return status;
            //         }
            //     };

            //     return (
            //         // <motion.div {...fadeInUp} key="orders">
            //         //     <div className="profile-page-content">
            //         //         <h2>Мои заказы</h2>
            //         //         {orders.length === 0 ? (
            //         //             <p>У вас пока нет заказов</p>
            //         //         ) : (
            //         //             <table className="orders-table">
            //         //                 <thead>
            //         //                     <tr>
            //         //                         <th>Номер заказа</th>
            //         //                         <th>Дата заказа</th>
            //         //                         <th>Тип доставки</th>
            //         //                         <th>Стоимость</th>
            //         //                         <th>Текущий статус</th>
            //         //                     </tr>
            //         //                 </thead>
            //         //                 <tbody>
            //         //                     {orders.map(order => (
            //         //                         <tr key={order.id}>
            //         //                             <td data-label="Номер заказа">
            //         //                                 <span className="order-number">№ {order.number}</span>
            //         //                             </td>
            //         //                             <td>{order.date_created}</td>
            //         //                             <td>{order.shipping_method}</td>
            //         //                             <td><strong>{order.total}</strong></td>
            //         //                             <td>
            //         //                                 <span className={`status ${getStatusClass(order.status)}`}>
            //         //                                     {getStatusText(order.status)}
            //         //                                 </span>
            //         //                             </td>
            //         //                         </tr>
            //         //                     ))}
            //         //                 </tbody>
            //         //             </table>
            //         //         )}
            //         //     </div>
            //         // </motion.div>
            //         <motion.div {...fadeInUp} key="orders">
            //             <div className="profile-page-content">
            //                 <h2>Мои заказы</h2>
            //                 {orders.length === 0 ? (
            //                     <p>У вас пока нет заказов</p>
            //                 ) : (
            //                     <>
            //                         <table className="orders-table">
            //                             {/* Существующая таблица */}
            //                             <tbody>
            //                                 {orders.map(order => (
            //                                     <tr
            //                                         key={order.id}
            //                                         onClick={() => setSelectedOrderId(order.id)}
            //                                         className="cursor-pointer hover:bg-gray-100"
            //                                     >
            //                                         {/* Существующие ячейки */}
            //                                     </tr>
            //                                 ))}
            //                             </tbody>
            //                         </table>

            //                         {/* Модальное окно с деталями заказа */}
            //                         {selectedOrderId && orderDetails && (
            //                             <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            //                                 <div className="bg-white p-6 rounded-lg max-w-md w-full max-h-[80vh] overflow-y-auto">
            //                                     <div className="flex justify-between items-center mb-4">
            //                                         <h3 className="text-xl font-bold">Детали заказа №{orderDetails.number}</h3>
            //                                         <button
            //                                             onClick={() => setSelectedOrderId(null)}
            //                                             className="text-gray-500 hover:text-gray-700"
            //                                         >
            //                                             ✕
            //                                         </button>
            //                                     </div>

            //                                     {/* Здесь можете добавить подробную информацию о заказе */}
            //                                     <div>
            //                                         <h4 className="font-semibold">Товары:</h4>
            //                                         {orderDetails.line_items.map((item: any) => (
            //                                             <div key={item.id} className="flex justify-between mb-2">
            //                                                 <span>{item.name}</span>
            //                                                 <span>{item.quantity} × {item.price} сум</span>
            //                                             </div>
            //                                         ))}

            //                                         <div className="mt-4">
            //                                             <p>Общая стоимость: <strong>{orderDetails.total} сум</strong></p>
            //                                             <p>Статус: {getStatusText(orderDetails.status)}</p>
            //                                             {/* Добавьте другие детали заказа */}
            //                                         </div>
            //                                     </div>
            //                                 </div>
            //                             </div>
            //                         )}
            //                     </>
            //                 )}
            //             </div>
            //         </motion.div>
            //     );
            // };
            case 'orders': {
                if (ordersLoading) {
                    return (
                        <motion.div {...fadeInUp} key="orders">
                            <div className="profile-page-content">
                                <h2>Мои заказы</h2>
                                <div className="loading">Загрузка заказов...</div>
                            </div>
                        </motion.div>
                    );
                }

                if (ordersError) {
                    return (
                        <motion.div {...fadeInUp} key="orders">
                            <div className="profile-page-content">
                                <h2>Мои заказы</h2>
                                <div className="error">{ordersError}</div>
                            </div>
                        </motion.div>
                    );
                }

                return (
                    <motion.div {...fadeInUp} key="orders">
                        <div className="profile-page-content">
                            <h2>Мои заказы</h2>
                            {orders.length === 0 ? (
                                <p>У вас пока нет заказов</p>
                            ) : (
                                <>
                                    <table className="orders-table">
                                        <thead>
                                            <tr>
                                                <th>Номер заказа</th>
                                                <th>Дата заказа</th>
                                                <th>Тип доставки</th>
                                                <th>Стоимость</th>
                                                <th>Текущий статус</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {orders.map(order => (
                                                <tr
                                                    key={order.id}
                                                    onClick={() => setSelectedOrderId(order.id)}
                                                // className="cursor-pointer hover:bg-gray-100"
                                                >
                                                    <td data-label="Номер заказа">
                                                        <span className="order-number">№ {order.number}</span>
                                                    </td>
                                                    <td>{order.date_created}</td>
                                                    <td>{order.shipping_method}</td>
                                                    <td><strong>{order.total}</strong></td>
                                                    <td>
                                                        <span className={`status ${getStatusClass(order.status)}`}>
                                                            {getStatusText(order.status)}
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>

                                    {/* Модальное окно с деталями заказа */}
                                    {selectedOrderId && orderDetails && (
                                        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                                            <div className="bg-white p-6 rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
                                                <div className="flex justify-between items-center mb-4">
                                                    <h3 className="text-xl font-bold">Детали заказа №{orderDetails.number}</h3>
                                                    <button
                                                        onClick={() => setSelectedOrderId(null)}
                                                        className="text-gray-500 hover:text-gray-700"
                                                    >
                                                        ✕
                                                    </button>
                                                </div>

                                                {/* Информация о покупателе */}
                                                <div className="mb-4">
                                                    <h4 className="font-semibold mb-2">Информация о покупателе</h4>
                                                    <p>ФИО: {orderDetails.billing.last_name} {orderDetails.billing.first_name}</p>
                                                    <p>Телефон: {orderDetails.billing.phone}</p>
                                                    <p>Дата создания заказа: {new Date(orderDetails.date_created).toLocaleString('ru-RU')}</p>
                                                </div>

                                                {/* Информация о доставке */}
                                                <div className="mb-4">
                                                    <h4 className="font-семибold mb-2">Доставка</h4>
                                                    <p>Адрес: {orderDetails.shipping.city}, {orderDetails.shipping.address_1}</p>
                                                    {orderDetails.shipping_lines.map((shipping, index) => {
                                                        // Конвертация стоимости доставки по фиксированным значениям
                                                        const shippingTotal = parseFloat(shipping.total);
                                                        let shippingUSD = '0.00';

                                                        if (shippingTotal === 25000) {
                                                            shippingUSD = '2.00';
                                                        } else if (shippingTotal === 65000) {
                                                            shippingUSD = '5.00';
                                                        }

                                                        return (
                                                            <p key={index}>
                                                                Доставка: {shipping.method_title} - {shippingUSD} $
                                                            </p>
                                                        );
                                                    })}
                                                </div>

                                                {/* Состав заказа */}
                                                <div>
                                                    <h4 className="font-semibold mb-2">Состав заказа</h4>
                                                    <table className="w-full border-collapse">
                                                        <thead>
                                                            <tr>
                                                                <th className="border p-2">Название товара</th>
                                                                <th className="border p-2">Артикул</th>
                                                                <th className="border p-2">Количество</th>
                                                                <th className="border p-2">Сумма</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {orderDetails.line_items.map((item) => {
                                                                // Конвертация цены в USD
                                                                const priceUSD = (item.price / 12800).toFixed(2);
                                                                return (
                                                                    <tr key={item.id}>
                                                                        <td className="border p-2">
                                                                            {/* <a
                                                                                href={`/product/${item.slug}`}
                                                                                target="_blank"
                                                                                rel="noopener noreferrer"
                                                                                className="text-blue-600 hover:underline"
                                                                            > */}
                                                                            {item.name}
                                                                            {/* </a> */}
                                                                        </td>
                                                                        <td className="border p-2">{item.sku}</td>
                                                                        <td className="border p-2">{item.quantity}</td>
                                                                        <td className="border p-2">{priceUSD} $</td>
                                                                    </tr>
                                                                );
                                                            })}
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <td colSpan={3} className="border p-2 font-bold text-right">Итого:</td>
                                                                <td className="border p-2 font-bold">
                                                                    {(parseFloat(orderDetails.total) / 12800).toFixed(2)} $
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </motion.div>
                );
            }
            case 'favorites':
                return (
                    <motion.div {...fadeInUp} key="favorites">
                        <div className="profile-page-content">
                            <h2>Избранное</h2>
                            <p>Ваши избранные товары пусты.</p>
                        </div>
                    </motion.div>
                );
            case 'points':
                return (
                    <motion.div {...fadeInUp} key="points">
                        <div className="profile-page-content">
                            <h2>Ваша накопительная карта</h2>
                            <div className="current_balance">
                                Текущий баланс: <span className='billz_point_value'>200 000</span> баллов
                            </div>
                            <div className="loyalty_image_block">
                                <img className='billz_cart_barcode' src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/913b2275733069210a8b889e89467b57.png" alt="barcode" />
                                <span className='billz_cart_number'>75894 2544 4989 15615</span>
                            </div>
                            <div className="loyalty_description_block">
                                <p className='main_loyalty_description'>
                                    ❇️ При покупке наших товаров отправляйте нам скриншот вашей карты и следите за вашими покупками,
                                    и программой лояльности прямо внутри бота.
                                </p>
                                <p>Программа лояльности Vitaline направлена на создание долгосрочных отношений с клиентами, предлагая им не только выгодные условия, но и возможность быть частью сообщества, заботящегося о здоровье.</p>
                                <br />
                                <p>С помощью этой программы Vitaline стремится сделать каждую покупку более приятной и выгодной для своих клиентов!</p>
                            </div>
                        </div>
                    </motion.div>
                );
            case 'support':
                return (
                    <motion.div {...fadeInUp} key="support">
                        <div className="profile-page-content">
                            {/* <h2>Служба поддержки</h2> */}
                            <div className="big_inf">
                                Свяжитесь с нами и мы поможем с любым вопросом касаемо внутренних процессов Vitaline - ассортимент, заказы, доставка.
                            </div>

                            <div className="smal_inf">
                                Рабочие дни с 9:00 до 19:00,
                                <br />прием заказов online 24/7
                            </div>

                            <div className="supp_block">

                                <div className="support_bottom_block">
                                    <h2 className='supp_page_head'>Служба поддержки Vitaline</h2>
                                    <div className="support_bottom_block_inner_wrap">
                                        <a href="https://t.me/support_chat" className="tg_chat_btn" target="_blank" rel="noopener noreferrer">
                                            <img alt="" src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/Artboard.svg" />
                                            <span>Открыть чат</span>
                                        </a>
                                        <div className="support-contacts">
                                            <p style={{ whiteSpace: "nowrap" }}>+998 95 099 00 90</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="contacts-social-links">
                                    <a href="#" className="contacts_insta">
                                        <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/Socials.svg" alt="" />
                                        <span>Инстаграм @vitaline.uz</span>
                                    </a>
                                    <a href="#" className="contacts_telegram">
                                        <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/Artboard.svg" alt="" />
                                        <span>Телеграм-канал Vitaline</span>
                                    </a>
                                </div>

                            </div>

                        </div>
                    </motion.div>
                );
            default:
                return null;
        }
    };

    const menuItems = (
        <ul>
            <li
                className={activeSection === 'profile' ? 'active' : ''}
                onClick={() => {
                    if (window.innerWidth <= 768) {
                        if (activeSection === 'profile') {
                            setIsMenuOpen(!isMenuOpen);
                        } else {
                            setActiveSection('profile');
                            setIsMenuOpen(false);
                        }
                    } else {
                        setActiveSection('profile');
                    }
                }}
            >
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_profile.png" alt="Иконка профиля" />
                <span>Мой профиль</span>
            </li>
            <li className={activeSection === 'orders' ? 'active' : ''}
                onClick={() => {
                    if (window.innerWidth <= 768) {
                        if (activeSection === 'orders') {
                            setIsMenuOpen(!isMenuOpen);
                        } else {
                            setActiveSection('orders');
                            setIsMenuOpen(false);
                        }
                    } else {
                        setActiveSection('orders');
                    }
                }}>
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_cart.png" alt="Иконка заказы" />
                <span>Мои заказы</span>
            </li>
            {/* <li className={activeSection === 'favorites' ? 'active' : ''}
                onClick={() => {
                    if (window.innerWidth <= 768) {
                        if (activeSection === 'favorites') {
                            setIsMenuOpen(!isMenuOpen);
                        } else {
                            setActiveSection('favorites');
                            setIsMenuOpen(false);
                        }
                    } else {
                        setActiveSection('favorites');
                    }
                }}>
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_favorite.png" alt="Иконка Избранное" />
                <span>Избранное</span>
            </li> */}
            <li className={activeSection === 'points' ? 'active' : ''}
                onClick={() => {
                    if (window.innerWidth <= 768) {
                        if (activeSection === 'points') {
                            setIsMenuOpen(!isMenuOpen);
                        } else {
                            setActiveSection('points');
                            setIsMenuOpen(false);
                        }
                    } else {
                        setActiveSection('points');
                    }
                }}>
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_points.png" alt="Иконка баллы" />
                <span>Мои баллы</span>
            </li>
            <li className={activeSection === 'support' ? 'active' : ''}
                onClick={() => {
                    if (window.innerWidth <= 768) {
                        if (activeSection === 'support') {
                            setIsMenuOpen(!isMenuOpen);
                        } else {
                            setActiveSection('support');
                            setIsMenuOpen(false);
                        }
                    } else {
                        setActiveSection('support');
                    }
                }}>
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_support.png" alt="Иконка поддержки" />
                <span>Служба поддержки</span>
            </li>

            <div className='side_nav_divider'></div>

            {/* <li
                onClick={() => {
                    localStorage.removeItem('authToken');
                    localStorage.removeItem('loginTimestamp');
                    window.location.href = '/login';
                }}
                className="logout"
            >
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_logout.png" alt="Иконка выхода" />
                <span>Выйти</span>
            </li> */}
            <li onClick={handleLogout} className="logout">
                <img src="https://nuxt.vitaline.uz/wp-content/uploads/2024/12/icon_logout.png" alt="Иконка выхода" />
                <span>Выйти</span>
            </li>
        </ul>
    );

    return (
        <AnimatedWrapper>
            <div className="profile-container">
                <aside className="sidebar_profile">
                    <div
                        className="mobile-dropdown-header"
                        onClick={() => {
                            if (window.innerWidth <= 768) {
                                setIsMenuOpen(!isMenuOpen);
                            }
                        }}
                    >
                        <span>
                            {activeSection === 'profile' ? 'Мой профиль' :
                                activeSection === 'orders' ? 'Мои заказы' :
                                    activeSection === 'favorites' ? 'Избранное' :
                                        activeSection === 'points' ? 'Мои баллы' :
                                            activeSection === 'support' ? 'Служба поддержки' : ''}
                        </span>
                        <span className={`dropdown-arrow ${isMenuOpen ? 'open' : ''}`}>
                            ▼
                        </span>
                    </div>
                    <div className={`menu-items ${isMenuOpen ? 'open' : ''}`}>
                        {menuItems}
                    </div>
                </aside>
                <main className="content-container">
                    {renderContent()}
                </main>
            </div>
        </AnimatedWrapper>
    );
}