// types/orders.ts
export interface WooOrder {
    id: number;
    number: string;
    date_created: string;
    status: string;
    shipping_lines: Array<{
        method_title: string;
    }>;
    total: string;
    payment_method_title: string;
}

export interface FormattedOrder {
    id: number;
    number: string;
    date_created: string;
    status: string;
    shipping_method: string;
    total: string;
    payment_method: string;
}